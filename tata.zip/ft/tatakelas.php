<form action=""method="POST" enctype="multipart/form-data">
    <h4>ID SISWA </h4>
    <input type="number" name= "id">
    <h4> NAMA KELAS </h4>
    <input type="number" name= "namakelas">
    <h4> KOMPETENSI </h4>
    <input type="number" name= "kompetensi">
    <h4> TAHUN PELAJARAN </H4>
    <input type="number" name= "tahun_pelajaran">
    <h4>KETERANGAN</h4>
    <input type="number" name= "keterangan"><br><br>
</form>
<?php
include "koneksi.php";
if (isset($_POST["klik"])) {
    mysqli_query($koneksi, "insert into siswa set id ='$_POST[id]', namakelas='$_POST[namakelas]', kompetensi='$_POST[kompetensi]', tahun_pelajaran=$_POST[tahun_pelajaran]',
    keterangan=$_POST[keterangan]");
}
?>