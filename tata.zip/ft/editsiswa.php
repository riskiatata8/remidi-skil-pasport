<body>
    <form method= "POST" enctype ="multipart/form-data" class ="box">
        <h2> Id</h2>
        <input type ="number" name= "id" placehorder="ID" value=<?php echo isset ($row['id']) ? $row['id'] : '';?>>
        <h2>Nama</h2>
        <input type ="text" name= "nama" placehorder="Nama" value=<?php echo isset ($row['nama']) ? $row['nama'] : '';?>>
        <h2> Tempat lahir </h2>
        <input type ="text" name= "tl" placehorder="Tempat lahir" value=<?php echo isset ($row['tplahir']) ? $row['tplahir'] : '';?>>
        <h2> Tanggal lahir</h2>
        <input type ="date" name= "tgl" placehorder="Tanggal lahir" value=<?php echo isset ($row['tglahir']) ? $row['tglahir'] : '';?>>
<h2> Alamat </h2>
<input type ="text" name= "alamat" placehorder="Alamat" value=<?php echo isset ($row['alamat']) ? $row['alamat'] : '';?>>
<h2> Hobi </h2>
<input type ="text" name= "hobi" placehorder="Hobi" value=<?php echo isset ($row['hobi']) ? $row['hobi'] : '';?>>
<h2> Cita cita</h2>
<input type ="text" name= "cita" placehorder="Cita cita" value=<?php echo isset ($row['cita_cita']) ? $row['cita_cita'] : '';?>>
<h2>Jumlah saudara</h2>
<input type ="text" name= "jmsaudara" placehorder="Jumlah saudara" value=<?php echo isset ($row['jmsaudara']) ? $row['jmsaudara'] : '';?>>
<h2> ID Kelas </H2>
<input type ="text" name= "idk" placehorder="ID Kelas" value=<?php echo isset ($row['idkelas']) ? $row['idkelas'] : '';?>>    
<h2> ID Agama</h2>
<input type ="text" name= "ida" placehorder="ID Agama" value=<?php echo isset ($row['idagama']) ? $row['idagama'] : '';?>>
</form>
</body>
<?php
include "koneksi.php";
if (isset($_POST["konfirmasi"])) {
    mysqli_query ($koneksi, "update siswa set id='$_POST[id]', nama='$_POST[nama]', tplahir='$_POST[tl]',tglahir='$_POST[tgl]', alamat='$_POST[alamat]',hobi='$_POST[hobi]',cita_cita='$_POST[cita]',jm_saudara='$_POST[jmsaudara]', idkelas='$_POST[idk]','idagama '$_POST[ida]'
    where id= $_GET[id]");
}
?>