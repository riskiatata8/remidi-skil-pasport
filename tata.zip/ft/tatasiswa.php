<form action="" method="POST" enctype="multipart/form.data">
<h4> ID SISWA</h4>
<input type ="number" name="id">
<h4> NAMA SISWA</h4>
<input type="text"name="nama">
<h4> TEMPAT TANGGAL LAHIR </h4>
<input type ="text" name="tplahir">
<h4> ALAMAT </h4>
<input type="text" name="alamat">
<h4> HOBI </h4>
<input type="text" name="hobi">
<h4> CITA CITA </h4>
<input type="text" name="cita_cita">
 <h4> JUMLAH SAUDARA</h4>
 <input type="text" name="jm_saudara">
 <h4> ID KELAS</h4>
 <input type="text" name="idkelas">
 <h4> ID AGAMA </h4>
 <input type="text" name="idagama"><br><br>
 <input type= "submit" name="klik" value = "klik">
</form>
<?php
include "koneksi.php";
if (isset($_POST["klik"])) { 
    mysqli_query  ($koneksi, "insert into siswa set id ='$_POST(id)',nama='$_POST[nama]',tplahir= '$_POST[tplahir]', alamat='$_POST[alamat]', 
    hobi='$_POST[hobi]', cita_cita='$_POST[cita_cita]', jm_saudara='$_POST[jm_saudara]',idkelas='$_POST[idkelas]',idagama='$_POST[idagama]'");
}
?>